//
//  AmaniVideo.h
//  AmaniVideo
//
//  Created by Deniz Can on 14.04.2023.
//

#import <Foundation/Foundation.h>

//! Project version number for AmaniVideo.
FOUNDATION_EXPORT double AmaniVideoVersionNumber;

//! Project version string for AmaniVideo.
FOUNDATION_EXPORT const unsigned char AmaniVideoVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <AmaniVideo/PublicHeader.h>


